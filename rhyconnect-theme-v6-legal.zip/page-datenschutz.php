<?php get_header(); ?>

<main class="main-content">
    <div class="container">
        <div class="legal-page">
            <h1>Datenschutzerklärung</h1>
            <div class="legal-content">
                
                <h2>1. Datenschutz auf einen Blick</h2>
                <h3>Allgemeine Hinweise</h3>
                <p>Die folgenden Hinweise geben einen einfachen Überblick darüber, was mit Ihren personenbezogenen Daten passiert, wenn Sie unsere App Rhyconnect nutzen. Personenbezogene Daten sind alle Daten, mit denen Sie persönlich identifiziert werden können.</p>

                <h3>Datenerfassung in der Rhyconnect App</h3>
                <p><strong>Wer ist verantwortlich für die Datenerfassung in dieser App?</strong></p>
                <p>Die Datenverarbeitung in dieser App erfolgt durch den App-Betreiber. Dessen Kontaktdaten können Sie dem Impressum dieser Website entnehmen.</p>

                <h2>2. Hosting und Content Delivery Networks (CDN)</h2>
                <h3>Externes Hosting</h3>
                <p>Diese Website wird bei einem externen Dienstleister gehostet (Hoster). Personenbezogenen Daten, die auf dieser Website erfasst werden, werden auf den Servern des Hosters gespeichert.</p>

                <h2>3. Allgemeine Hinweise und Pflichtinformationen</h2>
                <h3>Datenschutz</h3>
                <p>Die Betreiber dieser App nehmen den Schutz Ihrer persönlichen Daten sehr ernst. Wir behandeln Ihre personenbezogenen Daten vertraulich und entsprechend der gesetzlichen Datenschutzvorschriften sowie dieser Datenschutzerklärung.</p>

                <p>Wenn Sie die Rhyconnect App nutzen, werden verschiedene personenbezogene Daten erhoben. Personenbezogene Daten sind Daten, mit denen Sie persönlich identifiziert werden können.</p>

                <h3>Hinweis zur verantwortlichen Stelle</h3>
                <p>Die verantwortliche Stelle für die Datenverarbeitung in der Rhyconnect App ist:</p>
                <p>
                    [Firmenname]<br>
                    [Adresse]<br>
                    [PLZ, Ort]<br>
                    Schweiz
                </p>
                <p>
                    Telefon: [Telefonnummer]<br>
                    E-Mail: datenschutz@rhyconnect.app
                </p>

                <h3>Speicherdauer</h3>
                <p>Soweit innerhalb dieser Datenschutzerklärung keine speziellere Speicherdauer genannt wurde, verbleiben Ihre personenbezogenen Daten bei uns, bis der Zweck für die Datenverarbeitung entfällt.</p>

                <h2>4. Datenerfassung in der Rhyconnect App</h2>
                <h3>Nutzerkonto und Registrierung</h3>
                <p>Für die Nutzung der Rhyconnect App ist eine Registrierung erforderlich. Dabei erheben wir folgende Daten:</p>
                <ul>
                    <li>Benutzername</li>
                    <li>E-Mail-Adresse</li>
                    <li>Passwort (verschlüsselt gespeichert)</li>
                    <li>Profilbild (optional)</li>
                </ul>

                <h3>Event-Teilnahme und Verbindungen</h3>
                <p>Bei der Nutzung der App zur Teilnahme an Events und zum Knüpfen von Verbindungen erheben wir:</p>
                <ul>
                    <li>Standortdaten (bei Zustimmung)</li>
                    <li>Event-Teilnahme-Daten</li>
                    <li>Interaktionsdaten mit anderen Nutzern</li>
                    <li>Chat-Nachrichten</li>
                </ul>

                <h2>5. Ihre Rechte</h2>
                <h3>Auskunftsrecht</h3>
                <p>Sie haben jederzeit das Recht unentgeltlich Auskunft über Herkunft, Empfänger und Zweck Ihrer gespeicherten personenbezogenen Daten zu erhalten.</p>

                <h3>Recht auf Berichtigung, Löschung, Einschränkung</h3>
                <p>Sie haben das Recht, unrichtige Daten berichtigen oder löschen zu lassen. Ebenso können Sie die Einschränkung der Verarbeitung verlangen.</p>

                <h3>Recht auf Datenübertragbarkeit</h3>
                <p>Sie haben das Recht, dass wir Ihnen die Daten, die Sie uns bereitgestellt haben, in einem strukturierten, gängigen und maschinenlesbaren Format zur Verfügung stellen.</p>

                <h3>Widerspruchsrecht</h3>
                <p>Sie können der künftigen Verarbeitung der Sie betreffenden Daten jederzeit widersprechen.</p>

                <h2>6. Cookies und mobile Technologien</h2>
                <p>Die Rhyconnect App verwendet Cookies und ähnliche Technologien zur Verbesserung der Nutzererfahrung. Sie können die Cookie-Einstellungen in der App verwalten.</p>

                <h2>7. Datensicherheit</h2>
                <p>Wir verwenden geeignete technische und organisatorische Sicherheitsmaßnahmen, um Ihre Daten gegen zufällige oder vorsätzliche Manipulationen, teilweisen oder vollständigen Verlust, Zerstörung oder gegen den unbefugten Zugriff Dritter zu schützen.</p>

                <h2>8. Änderungen der Datenschutzerklärung</h2>
                <p>Wir behalten uns vor, diese Datenschutzerklärung zu ändern, um sie an geänderte Rechtslage oder bei Änderungen der App anzupassen. Für Ihren erneuten Besuch gilt dann die neue Datenschutzerklärung.</p>

                <p><strong>Stand: <?php echo date('d.m.Y'); ?></strong></p>

                <div class="legal-contact">
                    <h3>Kontakt bei Datenschutzfragen</h3>
                    <p>Bei Fragen zum Datenschutz wenden Sie sich bitte an:</p>
                    <p>E-Mail: datenschutz@rhyconnect.app</p>
                </div>
            </div>
        </div>
    </div>
</main>

<?php get_footer(); ?>