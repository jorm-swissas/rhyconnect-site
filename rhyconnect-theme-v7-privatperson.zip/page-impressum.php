<?php get_header(); ?>

<main class="main-content">
    <div class="container">
        <div class="legal-page">
            <h1>Impressum</h1>
            <div class="legal-content">
                
                <h2>Angaben gemäß Schweizer Recht</h2>
                
                <h3>Verantwortlich für den Inhalt</h3>
                <p>
                    <strong>[Ihr vollständiger Name]</strong><br>
                    Privater App-Entwickler<br>
                    [Ihre vollständige Privatadresse]<br>
                    [PLZ] [Ort]<br>
                    Schweiz
                </p>

                <h3>Kontakt</h3>
                <p>
                    <strong>Telefon:</strong> [Ihre Telefonnummer] (optional)<br>
                    <strong>E-Mail:</strong> [ihr.name]@rhyconnect.app<br>
                    <strong>Website:</strong> www.rhyconnect.app
                </p>

                <h3>Rechtliche Stellung</h3>
                <p>
                    <strong>Rechtsform:</strong> Privatperson / Einzelentwickler<br>
                    <strong>Geschäftstätigkeit:</strong> Entwicklung und Betrieb der Rhyconnect App<br>
                    <strong>Steuernummer:</strong> [Falls vorhanden - bei Einkommen über Freibetrag]
                </p>

                <h3>Hinweis zu Privatadresse</h3>
                <div style="background: #fff3cd; border: 1px solid #ffeaa7; padding: 1rem; border-radius: 5px; margin: 1rem 0;">
                    <p><strong>⚠️ Wichtiger Datenschutz-Hinweis:</strong></p>
                    <p>Da Sie als Privatperson agieren, können Sie folgende Optionen wählen:</p>
                    <ul>
                        <li><strong>Option A:</strong> Private Adresse angeben (gesetzlich erforderlich)</li>
                        <li><strong>Option B:</strong> Postfach mieten für Geschäftspost</li>
                        <li><strong>Option C:</strong> Virtual Office / Geschäftsadresse mieten</li>
                        <li><strong>Option D:</strong> Einzelfirma gründen</li>
                    </ul>
                </div>

                <h2>EU-Vertretung (DSGVO Art. 27)</h2>
                <p>Für EU-Angelegenheiten bezüglich Datenschutz:</p>
                <p>
                    [Name der EU-Vertretung oder Anwaltskanzlei]<br>
                    [Adresse in der EU]<br>
                    [PLZ] [Ort], [EU-Land]<br>
                    E-Mail: eu-vertreter@rhyconnect.app
                </p>

                <h2>Verantwortlich für journalistisch-redaktionelle Inhalte</h2>
                <p>
                    <strong>Redaktionell Verantwortlicher:</strong> [Name]<br>
                    [Adresse]<br>
                    [PLZ] [Ort]<br>
                    Schweiz
                </p>

                <h2>Haftungsausschluss</h2>
                
                <h3>Haftung für Inhalte</h3>
                <p>Die Inhalte unserer App und Website wurden mit größter Sorgfalt erstellt. Für die Richtigkeit, Vollständigkeit und Aktualität der Inhalte können wir jedoch keine Gewähr übernehmen.</p>

                <h3>Haftung für Links</h3>
                <p>Unsere App kann Links zu externen Websites Dritter enthalten. Auf den Inhalt dieser verlinkten Websites haben wir keinen Einfluss. Deshalb können wir für diese fremden Inhalte auch keine Gewähr übernehmen.</p>

                <h3>Nutzergenerierte Inhalte</h3>
                <p>Für Inhalte, die von Nutzern in der App erstellt werden, sind die jeweiligen Nutzer selbst verantwortlich. Wir moderieren Inhalte nach bestem Wissen, können aber nicht für alle Nutzerinhalte garantieren.</p>

                <h2>Urheberrecht</h2>
                <p>Die durch die Seitenbetreiber erstellten Inhalte und Werke in dieser App unterliegen dem schweizerischen Urheberrecht. Die Vervielfältigung, Bearbeitung, Verbreitung und jede Art der Verwertung außerhalb der Grenzen des Urheberrechtes bedürfen der schriftlichen Zustimmung des jeweiligen Autors bzw. Erstellers.</p>

                <h3>Markenrechte</h3>
                <p>
                    <strong>Rhyconnect</strong> ist eine eingetragene Marke von [Firmenname].<br>
                    Alle anderen Marken und Logos sind Eigentum ihrer jeweiligen Inhaber.
                </p>

                <h2>Streitbeilegung</h2>
                
                <h3>Online-Streitbeilegung (OS)</h3>
                <p>Die Europäische Kommission stellt eine Plattform zur Online-Streitbeilegung (OS) bereit: 
                <a href="https://ec.europa.eu/consumers/odr/" target="_blank" rel="noopener">https://ec.europa.eu/consumers/odr/</a></p>

                <h3>Verbraucherschlichtung</h3>
                <p>Wir sind nicht bereit oder verpflichtet, an Streitbeilegungsverfahren vor einer Verbraucherschlichtungsstelle teilzunehmen.</p>

                <h2>Technische Umsetzung</h2>
                <p>
                    <strong>App-Entwicklung:</strong> [Entwicklerfirma oder eigene Entwicklung]<br>
                    <strong>Hosting:</strong> [Hosting-Provider]<br>
                    <strong>Server-Standort:</strong> [Land/Region der Server]
                </p>

                <h2>Lizenzinformationen</h2>
                <h3>Open-Source-Software</h3>
                <p>Diese App verwendet verschiedene Open-Source-Bibliotheken. Eine vollständige Liste der verwendeten Bibliotheken und deren Lizenzen finden Sie in den App-Einstellungen unter "Lizenzen".</p>

                <div class="legal-contact">
                    <h3>Kontakt für rechtliche Angelegenheiten</h3>
                    <p>
                        <strong>Allgemeine Anfragen:</strong> info@rhyconnect.app<br>
                        <strong>Rechtliche Angelegenheiten:</strong> legal@rhyconnect.app<br>
                        <strong>Datenschutz:</strong> datenschutz@rhyconnect.app<br>
                        <strong>Presse:</strong> presse@rhyconnect.app
                    </p>
                </div>

                <p><strong>Stand: <?php echo date('d.m.Y'); ?></strong></p>
            </div>
        </div>
    </div>
</main>

<?php get_footer(); ?>